# Hoji — mod de Minecraft (Forge 1.20.1)

Hoji es una adorable hoja verde con vida propia.

- **Aparece** en bosques, junglas, taigas, sabanas, pantanos y cerezos, siempre cerca de hojas. Algunas en grupo y otras sueltas.
- **Se acerca a ti y juega**: da saltitos a tu alrededor. A veces suelta corazones.
- **Domesticar**: clic derecho con agua (cubo de agua o botella de agua). Funciona 1 de cada 3 veces.
- **Seguir / quedarse quieta**: Shift + clic derecho. Clic derecho con la mano vacía = caricias.
- **Crecimiento**: su presencia acelera árboles (brotes, como 1 polvo de hueso) y cultivos (como 2 polvos de hueso).
- **Polvo mágico**: lo sueltan de vez en cuando (sin hacerles daño) y al morir.
- **Lazo mágico** (1 cuerda + 3 polvo mágico): clic derecho a cualquier mob lo atrapa dentro del lazo; clic derecho en un bloque lo suelta.
- Otros objetos: Hoja especial (la atrae), Baya de Hoji (su comida favorita), huevo generador.

## Probarlo
`/summon hoji:hoji ~ ~ ~`
