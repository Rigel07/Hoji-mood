package com.hoji.item;

import com.hoji.ModSounds;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Lazo mágico: guarda cualquier mob (incluidos los de otros mods) dentro del objeto.
 * El mob desaparece del mundo y se guarda entero (todos sus datos) hasta que se suelta
 * haciendo clic derecho en un bloque.
 */
public class MagicLassoItem extends Item {
    public static final String TAG_CAPTURED = "CapturedEntity";

    public MagicLassoItem(Item.Properties properties) {
        super(properties);
    }

    public static boolean hasCaptured(ItemStack stack) {
        return stack.hasTag() && stack.getTag().contains(TAG_CAPTURED, Tag.TAG_COMPOUND);
    }

    private static Component entityName(CompoundTag data) {
        String id = data.getString("id");
        return EntityType.byString(id)
                .map(type -> (Component) type.getDescription())
                .orElse(Component.literal(id));
    }

    /** Intenta atrapar al mob. Solo se llama en el servidor. */
    public static boolean capture(ItemStack stack, Player player, LivingEntity target) {
        if (hasCaptured(stack) || target instanceof Player || !target.isAlive()) {
            return false;
        }
        target.ejectPassengers();
        target.stopRiding();
        CompoundTag data = new CompoundTag();
        if (!target.save(data)) {
            return false;
        }
        Component name = entityName(data);
        stack.getOrCreateTag().put(TAG_CAPTURED, data);
        if (target.level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.WITCH, target.getX(), target.getY() + target.getBbHeight() / 2.0D,
                    target.getZ(), 20, 0.3D, 0.3D, 0.3D, 0.1D);
            server.playSound(null, target.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 1.4F);
        }
        target.discard();
        player.displayClientMessage(Component.translatable("message.hoji.captured", name), true);
        return true;
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        ItemStack stack = context.getItemInHand();
        if (!hasCaptured(stack)) {
            return InteractionResult.PASS;
        }
        Level level = context.getLevel();
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        Player player = context.getPlayer();
        CompoundTag data = stack.getTag().getCompound(TAG_CAPTURED).copy();
        BlockPos pos = context.getClickedPos().relative(context.getClickedFace());

        Entity entity = EntityType.loadEntityRecursive(data, level, loaded -> {
            loaded.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, loaded.getYRot(), loaded.getXRot());
            return loaded;
        });
        if (entity == null) {
            if (player != null) {
                player.displayClientMessage(Component.translatable("message.hoji.release_failed"), true);
            }
            return InteractionResult.FAIL;
        }
        if (level instanceof ServerLevel server && server.getEntity(entity.getUUID()) != null) {
            entity.setUUID(UUID.randomUUID());
        }
        entity.setDeltaMovement(Vec3.ZERO);
        if (!level.addFreshEntity(entity)) {
            if (player != null) {
                player.displayClientMessage(Component.translatable("message.hoji.release_failed"), true);
            }
            return InteractionResult.FAIL;
        }
        stack.removeTagKey(TAG_CAPTURED);
        if (level instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.HAPPY_VILLAGER, entity.getX(), entity.getY() + 0.5D, entity.getZ(),
                    12, 0.3D, 0.3D, 0.3D, 0.0D);
            server.playSound(null, entity.blockPosition(), ModSounds.HOJI_HAPPY.get(), SoundSource.PLAYERS, 1.0F, 1.2F);
        }
        if (player != null) {
            player.displayClientMessage(Component.translatable("message.hoji.released", entity.getName()), true);
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return hasCaptured(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        if (hasCaptured(stack)) {
            tooltip.add(Component.translatable("item.hoji.magic_lasso.contains",
                    entityName(stack.getTag().getCompound(TAG_CAPTURED))).withStyle(ChatFormatting.LIGHT_PURPLE));
            tooltip.add(Component.translatable("item.hoji.magic_lasso.release").withStyle(ChatFormatting.GRAY));
        } else {
            tooltip.add(Component.translatable("item.hoji.magic_lasso.empty").withStyle(ChatFormatting.GRAY));
        }
    }
}
