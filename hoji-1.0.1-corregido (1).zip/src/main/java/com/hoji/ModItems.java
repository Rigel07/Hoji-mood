package com.hoji;

import com.hoji.item.MagicLassoItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, HojiMod.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, HojiMod.MODID);

    public static final RegistryObject<Item> MAGIC_DUST = ITEMS.register("magic_dust",
            () -> new Item(new Item.Properties()));

    public static final RegistryObject<Item> MAGIC_LASSO = ITEMS.register("magic_lasso",
            () -> new MagicLassoItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> HOJI_LEAF = ITEMS.register("hoji_leaf",
            () -> new Item(new Item.Properties()));

    public static final RegistryObject<Item> HOJI_BERRY = ITEMS.register("hoji_berry",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(2).saturationMod(0.3F).build())));

    public static final RegistryObject<Item> HOJI_SPAWN_EGG = ITEMS.register("hoji_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.HOJI, 0x7CC857, 0xF596AA, new Item.Properties()));

    public static final RegistryObject<CreativeModeTab> HOJI_TAB = TABS.register("hoji",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.hoji"))
                    .icon(() -> new ItemStack(HOJI_LEAF.get()))
                    .displayItems((parameters, output) ->
                            ITEMS.getEntries().forEach(item -> output.accept(item.get())))
                    .build());
}
