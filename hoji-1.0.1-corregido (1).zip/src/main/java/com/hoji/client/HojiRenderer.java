package com.hoji.client;

import com.hoji.HojiMod;
import com.hoji.entity.HojiEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class HojiRenderer extends MobRenderer<HojiEntity, HojiModel> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(HojiMod.MODID, "textures/entity/hoji.png");

    public HojiRenderer(EntityRendererProvider.Context context) {
        super(context, new HojiModel(context.bakeLayer(HojiModel.LAYER)), 0.3F);
    }

    @Override
    public ResourceLocation getTextureLocation(HojiEntity entity) {
        return TEXTURE;
    }
}
