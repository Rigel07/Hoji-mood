package com.hoji.client;

import com.hoji.HojiMod;
import com.hoji.entity.HojiEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Hoji: cuerpo redondito con hoja en la cabeza, ojos grandes, mejillas rosas, bracitos y patitas. */
public class HojiModel extends EntityModel<HojiEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(HojiMod.MODID, "hoji"), "main");

    private final ModelPart body;
    private final ModelPart leaf;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;

    public HojiModel(ModelPart root) {
        this.body = root.getChild("body");
        this.leaf = this.body.getChild("leaf");
        this.rightArm = this.body.getChild("right_arm");
        this.leftArm = this.body.getChild("left_arm");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg = root.getChild("left_leg");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition body = root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -7.0F, -3.0F, 8.0F, 7.0F, 6.0F),
                PartPose.offset(0.0F, 22.0F, 0.0F));

        // ojos, mejillas
        body.addOrReplaceChild("eyes",
                CubeListBuilder.create()
                        .texOffs(0, 13).addBox(-3.0F, -5.0F, -4.0F, 2.0F, 2.0F, 1.0F)
                        .texOffs(0, 13).addBox(1.0F, -5.0F, -4.0F, 2.0F, 2.0F, 1.0F)
                        .texOffs(6, 13).addBox(-4.0F, -3.0F, -3.5F, 2.0F, 1.0F, 1.0F)
                        .texOffs(6, 13).addBox(2.0F, -3.0F, -3.5F, 2.0F, 1.0F, 1.0F),
                PartPose.ZERO);

        // hoja de la cabeza (se balancea)
        body.addOrReplaceChild("leaf",
                CubeListBuilder.create()
                        .texOffs(28, 0).addBox(-3.0F, -2.0F, -2.5F, 6.0F, 2.0F, 5.0F)
                        .texOffs(28, 7).addBox(-2.0F, -4.0F, -2.0F, 4.0F, 2.0F, 4.0F)
                        .texOffs(44, 7).addBox(-1.0F, -6.0F, -1.5F, 2.0F, 2.0F, 3.0F),
                PartPose.offset(0.0F, -7.0F, 0.0F));

        body.addOrReplaceChild("right_arm",
                CubeListBuilder.create().texOffs(12, 13).addBox(-1.0F, 0.0F, -1.0F, 1.0F, 3.0F, 1.0F),
                PartPose.offset(-4.0F, -5.0F, 0.0F));
        body.addOrReplaceChild("left_arm",
                CubeListBuilder.create().texOffs(12, 13).addBox(0.0F, 0.0F, -1.0F, 1.0F, 3.0F, 1.0F),
                PartPose.offset(4.0F, -5.0F, 0.0F));

        CubeListBuilder leg = CubeListBuilder.create().texOffs(16, 13).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F);
        root.addOrReplaceChild("right_leg", leg, PartPose.offset(-2.0F, 22.0F, 0.0F));
        root.addOrReplaceChild("left_leg", leg, PartPose.offset(2.0F, 22.0F, 0.0F));

        return LayerDefinition.create(mesh, 64, 32);
    }

    @Override
    public void setupAnim(HojiEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        float rad = (float) Math.PI / 180.0F;
        boolean sitting = entity.isInSittingPose();

        // saltitos al andar y mirada hacia donde mira
        float hop = Math.abs(Mth.sin(limbSwing * 0.8F)) * 2.5F * limbSwingAmount;
        body.y = 22.0F - hop + (sitting ? 1.0F : 0.0F);
        body.yRot = netHeadYaw * rad * 0.5F;
        body.xRot = headPitch * rad * 0.3F + (sitting ? -0.15F : 0.0F);
        body.zRot = Mth.sin(limbSwing * 0.8F) * 0.12F * limbSwingAmount;

        // la hoja se balancea siempre
        leaf.zRot = Mth.sin(ageInTicks * 0.1F) * 0.12F + Mth.sin(limbSwing * 0.8F) * 0.2F * limbSwingAmount;
        leaf.xRot = -0.1F + Mth.cos(ageInTicks * 0.07F) * 0.05F;

        // bracitos: se agitan suavemente (más cuando está sentada, contenta)
        float wave = Mth.sin(ageInTicks * 0.2F) * (sitting ? 0.5F : 0.15F);
        rightArm.zRot = 0.3F + wave;
        leftArm.zRot = -0.3F - wave;

        if (sitting) {
            rightLeg.xRot = -1.3F;
            leftLeg.xRot = -1.3F;
        } else {
            float swing = Mth.cos(limbSwing * 0.8F) * 1.2F * limbSwingAmount;
            rightLeg.xRot = swing;
            leftLeg.xRot = -swing;
        }
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        body.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        rightLeg.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        leftLeg.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
