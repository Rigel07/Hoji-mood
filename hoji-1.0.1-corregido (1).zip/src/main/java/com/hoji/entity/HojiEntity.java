package com.hoji.entity;

import com.hoji.ModEntities;
import com.hoji.ModItems;
import com.hoji.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.SitWhenOrderedToGoal;
import net.minecraft.world.entity.ai.goal.TemptGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionUtils;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BonemealableBlock;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.SaplingBlock;
import net.minecraft.world.level.block.StemBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.tags.BlockTags;

public class HojiEntity extends TamableAnimal {
    private int growCooldown = 60;
    private int shedCooldown;
    private int petCooldown;

    public HojiEntity(EntityType<? extends HojiEntity> type, Level level) {
        super(type, level);
        this.shedCooldown = 3000 + this.random.nextInt(3000);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 8.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D);
    }

    /** Aparece en suelo firme, con luz y con hojas cerca. */
    public static boolean checkHojiSpawnRules(EntityType<HojiEntity> type, ServerLevelAccessor level,
                                              MobSpawnType reason, BlockPos pos, RandomSource random) {
        if (!level.getBlockState(pos.below()).isFaceSturdy(level, pos.below(), Direction.UP)) {
            return false;
        }
        if (level.getRawBrightness(pos, 0) < 8) {
            return false;
        }
        // IMPORTANT: during chunk generation the ServerLevelAccessor can be a
        // WorldGenRegion. Reading a block from a neighbouring chunk that has not
        // been generated yet can throw:
        // "NullPointerException: No chunk exists at [...]".
        // Keep the search inside the current chunk so the spawn predicate never
        // asks WorldGenRegion for an unavailable neighbouring chunk.
        int minX = Math.max(pos.getX() - 4, (pos.getX() >> 4) << 4);
        int maxX = Math.min(pos.getX() + 4, ((pos.getX() >> 4) << 4) + 15);
        int minZ = Math.max(pos.getZ() - 4, (pos.getZ() >> 4) << 4);
        int maxZ = Math.min(pos.getZ() + 4, ((pos.getZ() >> 4) << 4) + 15);

        for (int x = minX; x <= maxX; x++) {
            for (int y = pos.getY(); y <= pos.getY() + 5; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    if (level.getBlockState(new BlockPos(x, y, z)).is(BlockTags.LEAVES)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ IA

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new SitWhenOrderedToGoal(this));
        this.goalSelector.addGoal(2, new PanicGoal(this, 1.5D) {
            @Override
            public boolean canUse() {
                return !HojiEntity.this.isTame() && super.canUse();
            }
        });
        this.goalSelector.addGoal(3, new TemptGoal(this, 1.1D,
                Ingredient.of(ModItems.HOJI_LEAF.get(), ModItems.HOJI_BERRY.get()), false));
        this.goalSelector.addGoal(4, new FollowOwnerGoal(this, 1.1D, 6.0F, 2.0F, false));
        this.goalSelector.addGoal(5, new HojiPlayGoal(this));
        this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
    }

    // ----------------------------------------------------------- interacción

    private static boolean isWater(ItemStack stack) {
        return stack.is(Items.WATER_BUCKET)
                || (stack.is(Items.POTION) && PotionUtils.getPotion(stack) == Potions.WATER);
    }

    private static boolean isTreat(ItemStack stack) {
        return stack.is(ModItems.HOJI_BERRY.get()) || stack.is(ModItems.HOJI_LEAF.get());
    }

    public void playHappySound() {
        this.playSound(ModSounds.HOJI_HAPPY.get(), 0.7F, 1.0F + (this.random.nextFloat() - 0.5F) * 0.3F);
    }

    private void spawnHearts(int count) {
        if (this.level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.HEART, getX(), getY() + 0.7D, getZ(), count, 0.25D, 0.2D, 0.25D, 0.0D);
        }
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        boolean client = this.level().isClientSide;

        if (!isTame()) {
            if (isWater(stack)) {
                if (!client) {
                    ItemStack empty = stack.is(Items.WATER_BUCKET) ? new ItemStack(Items.BUCKET) : new ItemStack(Items.GLASS_BOTTLE);
                    player.setItemInHand(hand, ItemUtils.createFilledResult(stack, player, empty));
                    if (this.random.nextInt(3) == 0) {
                        tame(player);
                        this.navigation.stop();
                        setTarget(null);
                        setOrderedToSit(false);
                        setInSittingPose(false);
                        this.level().broadcastEntityEvent(this, (byte) 7);
                        playHappySound();
                    } else {
                        this.level().broadcastEntityEvent(this, (byte) 6);
                    }
                }
                return InteractionResult.sidedSuccess(client);
            }
            return InteractionResult.PASS;
        }

        if (!isOwnedBy(player)) {
            return InteractionResult.PASS;
        }

        if (isTreat(stack)) {
            if (!client) {
                if (!player.getAbilities().instabuild) {
                    stack.shrink(1);
                }
                heal(4.0F);
                this.playSound(ModSounds.HOJI_EAT.get(), 0.8F, 1.0F);
                spawnHearts(5);
            }
            return InteractionResult.sidedSuccess(client);
        }

        if (hand == InteractionHand.MAIN_HAND) {
            if (player.isShiftKeyDown()) {
                if (!client) {
                    boolean sit = !isOrderedToSit();
                    setOrderedToSit(sit);
                    this.navigation.stop();
                    setTarget(null);
                    player.displayClientMessage(
                            Component.translatable(sit ? "message.hoji.stay" : "message.hoji.follow"), true);
                }
                return InteractionResult.sidedSuccess(client);
            }
            if (stack.isEmpty()) {
                if (!client && petCooldown <= 0) {
                    petCooldown = 30;
                    spawnHearts(4);
                    playHappySound();
                }
                return InteractionResult.sidedSuccess(client);
            }
        }
        return InteractionResult.PASS;
    }

    // ------------------------------------------------------ vida y poderes

    @Override
    public void aiStep() {
        super.aiStep();
        if (!(this.level() instanceof ServerLevel server)) {
            return;
        }
        if (petCooldown > 0) {
            petCooldown--;
        }
        // De vez en cuando suelta corazones, como si la estuvieras domesticando.
        if (this.random.nextInt(isTame() ? 160 : 300) == 0) {
            spawnHearts(2);
            if (this.random.nextInt(2) == 0) {
                playHappySound();
            }
        }
        // Su presencia ayuda a crecer a árboles y cultivos.
        if (--growCooldown <= 0) {
            growCooldown = 80 + this.random.nextInt(60);
            growNearby(server);
        }
        // Suelta polvo mágico de vez en cuando.
        if (--shedCooldown <= 0) {
            shedCooldown = 4000 + this.random.nextInt(4000);
            this.spawnAtLocation(new ItemStack(ModItems.MAGIC_DUST.get()));
            server.sendParticles(ParticleTypes.HAPPY_VILLAGER, getX(), getY() + 0.5D, getZ(), 8, 0.3D, 0.3D, 0.3D, 0.0D);
        }
    }

    /** Árboles (brotes): como 1 polvo de hueso. Cultivos: como 2 polvos de hueso. */
    private void growNearby(ServerLevel server) {
        BlockPos origin = this.blockPosition();
        for (int i = 0; i < 6; i++) {
            BlockPos pos = origin.offset(this.random.nextInt(9) - 4, this.random.nextInt(5) - 2, this.random.nextInt(9) - 4);
            Block block = server.getBlockState(pos).getBlock();
            int applications;
            if (block instanceof SaplingBlock) {
                applications = 1;
            } else if (block instanceof CropBlock || block instanceof StemBlock) {
                applications = 2;
            } else {
                continue;
            }
            boolean grew = false;
            for (int a = 0; a < applications; a++) {
                BlockState state = server.getBlockState(pos);
                if (state.getBlock() instanceof BonemealableBlock bonemealable
                        && bonemealable.isValidBonemealTarget(server, pos, state, false)) {
                    if (bonemealable.isBonemealSuccess(server, server.random, pos, state)) {
                        bonemealable.performBonemeal(server, server.random, pos, state);
                        grew = true;
                    }
                } else {
                    break;
                }
            }
            if (grew) {
                server.sendParticles(ParticleTypes.HAPPY_VILLAGER, pos.getX() + 0.5D, pos.getY() + 0.5D,
                        pos.getZ() + 0.5D, 6, 0.3D, 0.3D, 0.3D, 0.0D);
            }
        }
    }

    // ---------------------------------------------------------------- sonidos

    @Override
    protected SoundEvent getAmbientSound() {
        return ModSounds.HOJI_AMBIENT.get();
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ModSounds.HOJI_HURT.get();
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.HOJI_DEATH.get();
    }

    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob mate) {
        return ModEntities.HOJI.get().create(level);
    }
}
