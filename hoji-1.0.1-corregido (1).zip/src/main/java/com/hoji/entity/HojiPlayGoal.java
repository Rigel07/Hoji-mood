package com.hoji.entity;

import java.util.EnumSet;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.player.Player;

/** Hoji se acerca a un jugador (su dueño si está domesticada) y juega a su alrededor dando saltitos. */
public class HojiPlayGoal extends Goal {
    private final HojiEntity hoji;
    private Player target;
    private int playTicks;
    private int moveTimer;
    private int jumpTimer;

    public HojiPlayGoal(HojiEntity hoji) {
        this.hoji = hoji;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (hoji.isOrderedToSit() || hoji.isLeashed() || hoji.isPassenger()) {
            return false;
        }
        if (hoji.getRandom().nextInt(hoji.isTame() ? 60 : 12) != 0) {
            return false;
        }
        Player candidate;
        if (hoji.isTame()) {
            LivingEntity owner = hoji.getOwner();
            if (!(owner instanceof Player ownerPlayer) || ownerPlayer.isSpectator()
                    || hoji.distanceToSqr(ownerPlayer) > 100.0D) {
                return false;
            }
            candidate = ownerPlayer;
        } else {
            candidate = hoji.level().getNearestPlayer(TargetingConditions.forNonCombat().range(14.0D), hoji);
            if (candidate == null) {
                return false;
            }
        }
        this.target = candidate;
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        return playTicks > 0 && target != null && target.isAlive() && !target.isSpectator()
                && !hoji.isOrderedToSit() && hoji.distanceToSqr(target) < 400.0D;
    }

    @Override
    public void start() {
        this.playTicks = 200 + hoji.getRandom().nextInt(200);
        this.moveTimer = 0;
        this.jumpTimer = 15 + hoji.getRandom().nextInt(20);
    }

    @Override
    public void stop() {
        this.target = null;
        hoji.getNavigation().stop();
    }

    @Override
    public void tick() {
        playTicks--;
        hoji.getLookControl().setLookAt(target, 30.0F, 30.0F);
        double distance = hoji.distanceTo(target);
        if (distance > 4.0D) {
            if (--moveTimer <= 0) {
                moveTimer = 10;
                hoji.getNavigation().moveTo(target, 1.2D);
            }
        } else {
            if (--moveTimer <= 0) {
                moveTimer = 20 + hoji.getRandom().nextInt(25);
                double angle = hoji.getRandom().nextDouble() * Math.PI * 2.0D;
                double radius = 1.5D + hoji.getRandom().nextDouble() * 1.5D;
                hoji.getNavigation().moveTo(target.getX() + Math.cos(angle) * radius, target.getY(),
                        target.getZ() + Math.sin(angle) * radius, 1.0D);
            }
            if (--jumpTimer <= 0) {
                jumpTimer = 25 + hoji.getRandom().nextInt(30);
                hoji.getJumpControl().jump();
                if (hoji.getRandom().nextInt(3) == 0) {
                    hoji.playHappySound();
                }
            }
        }
    }
}
